# hostSentry - Login Anomaly Detector Default TTY Tracker
#
# Author: Craig H. Rowland <crowland@psionic.com>
# Created: 10-6-98
#
# Send all changes/modifications/bugfixes to the above address.  
# 
# This software is Copyright(c) 1997-98 Craig H. Rowland
# 
# Disclaimer:
# 
# All software distributed by Craig H. Rowland ("the author") and
# Psionic Systems is distributed AS IS and carries NO WARRANTY or
# GUARANTEE OF ANY KIND. End users of the software acknowledge that         
# they will not hold the author, Psionic Systems, and any employer of    
# the author liable for failure or non-function of a software
# product. YOU ARE USING THIS PRODUCT AT YOUR OWN RISK
# 
# Licensing restrictions apply. See the license that came with this
# file for more information or visit http://www.psionic.com for more
# information.
# 
# This software is NOT GPL NOR PUBLIC DOMAIN so please read the license   
# before modifying or distributing. Contact the above address if you have
# any questions.
# 
# $Id: hostSentryTTY.py,v 1.1 1999/03/22 04:56:52 crowland Exp crowland $

# Schema version
DBVERSION = 1

# TTY Object definition
class hostSentryTTY:

	def __init__(self):
		self.__tty=''
		self.__loginStamp = ''
		self.__version=DBVERSION
		self.__username=''

	def setTty(self, tty):
		self.__tty = tty

	def getTty(self):
		return self.__tty

	def setLoginStamp(self, loginStamp):
		self.__loginStamp = loginStamp

	def getLoginStamp(self):
		return self.__loginStamp

	def setUsername(self, username):
		self.__username = username

	def getUsername(self):
		return self.__username

 
