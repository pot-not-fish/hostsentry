# hostSentry - Login Anomaly Detector Core Class and Exception Handler
#
# Author: Craig H. Rowland <crowland@psionic.com>
# Created: 10-6-98
#
# Send all changes/modifications/bugfixes to the above address.  
# 
# This software is Copyright(c) 1997-98 Craig H. Rowland
# 
# Disclaimer:
# 
# All software distributed by Craig H. Rowland ("the author") and
# Psionic Systems is distributed AS IS and carries NO WARRANTY or
# GUARANTEE OF ANY KIND. End users of the software acknowledge that         
# they will not hold the author, Psionic Systems, and any employer of    
# the author liable for failure or non-function of a software
# product. YOU ARE USING THIS PRODUCT AT YOUR OWN RISK
# 
# Licensing restrictions apply. See the license that came with this
# file for more information or visit http://www.psionic.com for more
# information.
# 
# This software is NOT GPL NOR PUBLIC DOMAIN so please read the license   
# before modifying or distributing. Contact the above address if you have
# any questions.
# 
# $Id: hostSentryCore.py,v 1.1 1999/03/22 04:56:39 crowland Exp crowland $



########################################
# Common core methods for all of hostSentry
########################################
class hostSentryCore:

	def __init__(self):
		self.__logLevel = 0

	def setLogLevel(self, level=0):
		self.__logLevel = level

	def getLogLevel(self):
		return self.__logLevel

########################################
# Exception Class.
########################################
class hostSentryError(StandardError):
	# I'm not sure if I like doing this or
	# not. I may change this in the future.
        pass


